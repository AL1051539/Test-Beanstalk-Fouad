This bundle source is a fork of the official bundle source : __correto.zip__
https://docs.aws.amazon.com/fr_fr/elasticbeanstalk/latest/dg/tutorials.html

The goals of this custom version is provide a very light Java application already compiled and deploy it on the Java SE platform.

This therefore makes it possible to avoid a compilation phase on the Beanstalk environment (consequently no calls to the Maven repository).

The content of this bundle source :
- un jar file corresponding to the Java application to deployed
- a config file with the port used by the application (5000)